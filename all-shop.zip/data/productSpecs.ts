
import { Product } from '../types';

export const PRODUCT_SPECS: Record<number, Record<string, string | boolean>> = {
    // Xiaomi TV Box S (2nd Gen) - ID 6 (Exemplo)
    6: {
        "Resolução": "4K Ultra HD",
        "Processador": "Quad-Core Cortex-A55",
        "RAM": "2GB",
        "Armazenamento": "8GB",
        "Sistema Operativo": "Google TV",
        "Conectividade": "Wi-Fi 2.4GHz/5GHz, Bluetooth 5.2",
        "Portas": "HDMI 2.1, USB 2.0, Áudio",
        "Comando de Voz": true
    },
    // Exemplo genérico para IDs que possamos adivinhar ou para testes
    1: {
        "Autonomia": "30 Horas",
        "Cancelamento de Ruído": true,
        "Bluetooth": "5.3",
        "Resistência à Água": "IPX4",
        "Tipo": "Over-Ear"
    }
};

export const CATEGORY_DEFAULT_SPECS: Record<string, Record<string, string | boolean>> = {
    "Gaming": {
        "Processador": "AMD Ryzen Z1 Extreme",
        "GPU": "RDNA 3",
        "RAM": "16GB LPDDR5X",
        "Ecrã": "7\" 120Hz VRR",
        "Armazenamento": "512GB NVMe",
        "Bateria": "40Wh"
    },
    "Smart Home": {
        "Compatibilidade": "Google Home, Alexa",
        "Conectividade": "Wi-Fi, Zigbee",
        "Alimentação": "Bateria / Cabo",
        "Instalação": "Fácil (DIY)",
        "App Mobile": true
    },
    "Audio": {
        "Autonomia": "24 Horas",
        "Cancelamento de Ruído": "Ativo (ANC)",
        "Bluetooth": "5.2",
        "Microfone": "Integrado (4 mics)",
        "Carregamento Rápido": true
    },
    "Drones": {
        "Tempo de Voo": "34 Minutos",
        "Alcance": "12 km",
        "Câmara": "4K HDR",
        "Estabilização": "Gimbal 3 Eixos",
        "Peso": "< 249g"
    },
    "Carregadores": {
        "Potência Máxima": "65W",
        "Portas": "2x USB-C, 1x USB-A",
        "Tecnologia": "GaN (Nitreto de Gálio)",
        "Proteção": "Sobreaquecimento, Curto-circuito",
        "Compatibilidade": "Universal"
    },
    "Acessórios": {
        "Material": "Nylon Trançado",
        "Comprimento": "2 Metros",
        "Garantia": "3 Anos",
        "Certificação": "MFi / CE"
    }
};

export const getSpecsForProduct = (product: Product): Record<string, string | boolean> => {
    // 1. Tenta encontrar specs específicas pelo ID
    if (PRODUCT_SPECS[product.id]) {
        return PRODUCT_SPECS[product.id];
    }

    // 2. Se não tiver, tenta encontrar pela Categoria
    const categorySpecs = CATEGORY_DEFAULT_SPECS[product.category] || CATEGORY_DEFAULT_SPECS['Acessórios'];
    
    // Retorna specs genéricas (mock) para preencher a tabela se não houver dados reais
    // Num cenário real, isto viria da base de dados.
    return categorySpecs;
};
